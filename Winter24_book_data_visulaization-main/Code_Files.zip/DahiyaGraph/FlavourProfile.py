import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.express as px

# Read the CSV file
df = pd.read_csv("fdb_molecules.csv")

# Split the fooddb_flavor_profile column by '@' and explode into separate rows
df['fooddb_flavor_profile'] = df['fooddb_flavor_profile'].str.split('@')
df = df.explode('fooddb_flavor_profile')

# Get the top 15 flavor profiles
top_flavor_profiles = df['fooddb_flavor_profile'].value_counts().head(15)

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1("Visualization of FoodDB Flavor Profiles"),
    dcc.Dropdown(
        id='chart-type',
        options=[
            {'label': 'Pie Chart', 'value': 'pie'},
            {'label': 'Bar Chart', 'value': 'bar'},
            {'label': 'Histogram', 'value': 'histogram'}
        ],
        value='pie'
    ),
    dcc.Graph(id='chart')
])

# Define callback to update the graph based on dropdown selection
@app.callback(
    Output('chart', 'figure'),
    [Input('chart-type', 'value')]
)
def update_chart(chart_type):
    if chart_type == 'pie':
        fig = px.pie(names=top_flavor_profiles.index, values=top_flavor_profiles.values, title='Top 15 FoodDB Flavor Profiles')
    elif chart_type == 'bar':
        fig = px.bar(x=top_flavor_profiles.index, y=top_flavor_profiles.values, title='Top 15 FoodDB Flavor Profiles')
    else :
        fig = px.histogram(x=df['fooddb_flavor_profile'], title='FoodDB Flavor Profile Distribution')
    return fig

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)