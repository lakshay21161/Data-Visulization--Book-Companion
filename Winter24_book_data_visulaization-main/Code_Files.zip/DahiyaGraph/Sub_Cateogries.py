import pandas as pd
import plotly.graph_objects as go

# Step 1: Load Data
data = pd.read_csv('fdb_entities.csv')

# Step 2: Data Preparation
category_counts = data['category_readable'].value_counts()
subcategory_data = {}
for category in category_counts.index:
    subcategory_counts = data[data['category_readable'] == category]['entity_alias'].value_counts()
    subcategory_data[category] = subcategory_counts

# Step 3: Create Initial Pie Chart
fig = go.Figure()

for category in category_counts.index:
    fig.add_trace(go.Pie(labels=subcategory_data[category].index,
                         values=subcategory_data[category].values,
                         name=category,
                         visible='legendonly'))  # Initially hide all but first pie chart

fig.update_layout(updatemenus=[dict(type='buttons',
                                    direction='down',
                                    buttons=[dict(label=category,
                                                  method='update',
                                                  args=[{'visible': [category == trace.name for trace in fig.data]}])
                                             for category in category_counts.index])])

fig.update_layout(title='Top Categories')

# Step 5: Display Interactive Plot
fig.show()
