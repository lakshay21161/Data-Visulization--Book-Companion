## Natural Occurance

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd


# Read the CSV file
df = pd.read_csv("fdb_fn_properties.csv")

# Filter out empty cells and categorize based on 'not' prefix
filtered_data = df[df['Natural_occurrence'].notnull()]
categorized_data = filtered_data['Natural_occurrence'].apply(lambda x: 'Not naturally occuring' if x.startswith('Not') else 'Naturally occuring')

# Count occurrences of each category
counts = categorized_data.value_counts()

# Sample data for the bar chart
x_data = counts.index
y_data = counts

# Sample data for the pie chart
labels = counts.index
values = counts

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1("Bar Chart & Pie Chart"),
    dcc.Dropdown(
        id='chart-type',
        options=[
            {'label': 'Bar', 'value': 'bar'},
            {'label': 'Pie', 'value': 'pie'}
        ],
        value='bar'
    ),
    dcc.Graph(id='chart')
])

# Define callback to update the graph based on dropdown selection
@app.callback(
    Output('chart', 'figure'),
    [Input('chart-type', 'value')]
)
def update_chart(chart_type):
    if chart_type == 'bar':
        trace = go.Bar(x=x_data, y=y_data)
        layout = go.Layout(title='Natural Occurence')
    else:
        trace = go.Pie(labels=labels, values=values)
        layout = go.Layout(title='Natural Occurence')
    return {'data': [trace], 'layout': layout}

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
