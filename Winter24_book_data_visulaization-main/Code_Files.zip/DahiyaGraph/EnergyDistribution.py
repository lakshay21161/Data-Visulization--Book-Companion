import pandas as pd
import matplotlib.pyplot as plt

# Read the CSV file into a DataFrame
df = pd.read_csv("fdb_more_properties.csv")

# Assuming "energy" is the column you want to plot
energy_values = df["energy"]

# Plot the data
plt.figure(figsize=(10, 6))  # Set the size of the figure
plt.plot(energy_values, color='blue', marker='o', linestyle='-')  # Plot energy values
plt.title("Energy Distribution")  # Set the title of the plot
plt.xlabel("Index") # Set the label for the x-axis
plt.ylabel("Energy")  # Set the label for the y-axis
plt.ylim(0, 3000)  # Set the y-axis limits
plt.grid(True)  # Add gridlines to the plot
plt.show()  # Show the plot

import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read the CSV file
df = pd.read_csv("fdb_more_properties.csv")

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1("Energy Distribution"),
    dcc.Dropdown(
        id='chart-type',
        options=[
            {'label': 'Histogram', 'value': 'histogram'},
            {'label': 'Violin Plot', 'value': 'violin'}
        ],
        value='histogram'
    ),
    dcc.Graph(id='chart')
])

# Define callback to update the graph based on dropdown selection
@app.callback(
    Output('chart', 'figure'),
    [Input('chart-type', 'value')]
)
def update_chart(chart_type):
    threshold = 300  # Adjust as needed based on your data
    # Filter out outliers
    df_filtered = df[df['energy'] < threshold]
    # Add a dummy category column
    df_filtered['category'] = 'All Dishes'

    if chart_type == 'histogram':
        # Plot the histogram
        trace = go.Histogram(x=df_filtered['energy'], nbinsx=30, marker_color='blue', opacity=0.7)
        layout = go.Layout(title='Energy Distribution', xaxis=dict(title='Energy'), yaxis=dict(title='Frequency'))
    else:
        # Plot the violin plot
        trace = go.Violin(y=df_filtered['energy'], box_visible=True, line_color='blue', meanline_visible=True, fillcolor='lightblue')
        layout = go.Layout(title='Energy Distribution', yaxis=dict(title='Energy'))

    return {'data': [trace], 'layout': layout}

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
