## Receptors
import pandas as pd
import plotly.express as px

# Assuming 'receptor_name' column contains the receptors
# Replace 'file_path.csv' with the actual path to your CSV file
df = pd.read_csv('fdb_receptors.csv')
df = df.dropna(subset=['receptor_name'])

# Define categories based on common prefixes
categories = {
    'mGluR': ['mGluR4', 'mGluR1'],
    'TAS2R': ['TAS2R1', 'TAS2R3', 'TAS2R4', 'TAS2R5', 'TAS2R7', 'TAS2R8', 'TAS2R9', 'TAS2R10',
              'TAS2R13', 'TAS2R14', 'TAS2R16', 'TAS2R19', 'TAS2R20', 'TAS2R30', 'TAS2R31',
              'TAS2R38', 'TAS2R39', 'TAS2R40', 'TAS2R41', 'TAS2R42', 'TAS2R43', 'TAS2R45',
              'TAS2R46', 'TAS2R50', 'TAS2R60'],
    'TAS1R': ['TAS1R1', 'TAS1R2', 'TAS1R3'],
    'PKD2L1': ['PKD2L1'],
    'HCN': ['HCN1', 'HCN4'],
    'OR': [col for col in df['receptor_name'] if col.startswith('OR')],
    'CNGA': ['CNGA2', 'CNCA', 'CNCA1', 'CNCG2'],
    'GNAL': ['GNAL'],
    'GFY': ['GFY'],
    'VN1R': ['VN1R1', 'V1RL1', 'VNR19I1']
}

# Count the number of receptors in each category
category_counts = {category: sum(receptor in category_receptors for receptor in df['receptor_name'])
                  for category, category_receptors in categories.items()}

# Calculate percentages


# Calculate percentages
total_receptors = sum(category_counts.values())
percentages = {category: count / total_receptors * 100 for category, count in category_counts.items()}

# Create a DataFrame for Plotly
data = pd.DataFrame({'Category': list(category_counts.keys()), 'Count': list(category_counts.values()), 'Percentage': list(percentages.values())})

# Create a Plotly bar plot
fig = px.bar(data, x='Category', y='Count', hover_data={'Percentage': ':.2f%'}, color='Count',
             labels={'Count': 'Count', 'Category': 'Receptor Categories', 'Percentage': 'Percentage'},
             title='Distribution of Receptor Categories')

# Update hover template to include category names on X-axis
fig.update_traces(hovertemplate='<b>%{x}</b><br>Count: %{y}<br>')

# Show the plot
fig.show()