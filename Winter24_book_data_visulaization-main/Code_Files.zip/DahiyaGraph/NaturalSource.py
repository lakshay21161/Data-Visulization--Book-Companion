import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import pandas as pd
import plotly.express as px

# Read the CSV file
df = pd.read_csv("fdb_entities.csv")

# Get the top 20 natural sources from the 'natural_source_name' column
top_sources = df['natural_source_name'].value_counts().head(20).index.tolist()

# Filter the dataframe based on the top 20 natural sources
df_top_sources = df[df['natural_source_name'].isin(top_sources)]

# Initialize the Dash app
app = dash.Dash(__name__)

# Define the layout of the app
app.layout = html.Div([
    html.H1("Visualization of Top 20 Natural Sources"),
    dcc.Dropdown(
        id='chart-type',
        options=[
            {'label': 'Bar Chart', 'value': 'bar'},
            {'label': 'Pie Chart', 'value': 'pie'},
            {'label': 'Histogram', 'value': 'histogram'},
            {'label': 'Box Plot', 'value': 'box'},
            {'label': 'Treemap', 'value': 'treemap'}
        ],
        value='bar'
    ),
    dcc.Graph(id='chart')
])

# Define callback to update the graph based on dropdown selection
@app.callback(
    Output('chart', 'figure'),
    [Input('chart-type', 'value')]
)
def update_chart(chart_type):
    if chart_type == 'bar':
        top_sources_count = df_top_sources['natural_source_name'].value_counts().head(20)
        trace = go.Bar(x=top_sources_count.index, y=top_sources_count.values)
        layout = go.Layout(title='Top 20 Natural Sources Distribution - Bar Chart')
    elif chart_type == 'histogram':
        trace = go.Histogram(x=df_top_sources['natural_source_name'])
        layout = go.Layout(title='Top 20 Natural Sources Distribution - Histogram')
    elif chart_type == 'box':
        fig_box_source = px.box(df_top_sources, x='natural_source_name', title='Box Plot of Top 20 Natural Sources')
        return fig_box_source
    elif chart_type == 'treemap':
        fig_treemap = px.treemap(df_top_sources, path=['natural_source_name'], title='Treemap of Top 20 Natural Sources')
        return fig_treemap
    else:
        pie_data = df_top_sources['natural_source_name'].value_counts().head(20)
        trace = go.Pie(labels=pie_data.index, values=pie_data.values)
        layout = go.Layout(title='Top 20 Natural Sources Distribution - Pie Chart')

    return {'data': [trace], 'layout': layout}

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
