import pandas as pd
import plotly.express as px

# Step 1: Load Data
data = pd.read_csv('fdb_entities.csv')

# Step 2: Data Preparation
category_counts = data['category_readable'].value_counts()
subcategory_data = {}
for category in category_counts.index:
    subcategory_counts = data[data['category_readable'] == category]['entity_alias'].value_counts()
    subcategory_data[category] = subcategory_counts

# Step 3: Create Initial Treemap
fig = px.treemap(names=category_counts.index,
                 parents=['']*len(category_counts),
                 values=category_counts.values,
                 hover_data=[category_counts.index, category_counts.values],
                 title='Top Categories')

# Step 4: Add Clickable Behavior
def update_treemap(trace, points, selector):
    category = points.label['name']
    subcategory_counts = subcategory_data[category]
    subfig = px.treemap(names=subcategory_counts.index,
                        parents=['']*len(subcategory_counts),
                        values=subcategory_counts.values,
                        hover_data=[subcategory_counts.index, subcategory_counts.values],
                        title=f'Subcategories of {category}')
    subfig.show()

fig.for_each_trace(lambda t: t.on_click(update_treemap))

# Step 5: Display Treemap
fig.show()